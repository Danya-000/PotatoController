import ctypes
import keyboard
import time
from PIL import ImageGrab

class POINT(ctypes.Structure):
    _fields_= [("x", ctypes.c_long), ("y", ctypes.c_long)]

def screenshot(filename_or_path="screenshot.png"):
    """Делаем скриншот"""
    ImageGrab.grab().save(filename_or_path)

def ScreenSize():
    """Получаем размер экрана"""
    return ctypes.windll.user32.GetSystemMetrics(0), ctypes.windll.user32.GetSystemMetrics(1)

def Getpos():
    """Получаем координаты мышки"""
    point = POINT()
    ctypes.windll.user32.GetCursorPos(ctypes.byref(point))
    return point.x, point.y

def move(x=1, y=1):
    """Передвигаем мышку (моментально, может перенести за экран)"""
    ctypes.windll.user32.SetCursorPos(x, y)

def click(x=0, y=0, click="left", clicks=1, interval=0.1):
    """
    Нажимаем мышкой на координаты
    (по именно указанным координатам или там где мышка и стоит)
    """
    if not x==0 and not y==0:
        start_x, start_y = Getpos()
        move(x, y) 
    for num_click in range(0, clicks):
        if click == "left":
            ctypes.windll.user32.mouse_event(0x0002, 0, 0, 0, 0) # нажатие левой кнопки
            ctypes.windll.user32.mouse_event(0x0004, 0, 0, 0, 0) # отпускание левой кнопки
        elif click == "right":
            ctypes.windll.user32.mouse_event(0x0008, 0, 0, 0, 0) # нажатие левой кнопки
            ctypes.windll.user32.mouse_event(0x0010, 0, 0, 0, 0) # отпускание левой кнопки
        time.sleep(interval)
    if not x==0 and not y==0:  
        move(start_x, start_y)

def press(key="esc", clicks=1, interval=0.1):
    """Нажимаем кнопку (считая esc, shift, ctrl и все остальные)"""
    for click in range(0, clicks):
        keyboard.press(key)
        time.sleep(interval)

def WriteText(text, interval=0):
    """Печатаем текст"""
    if interval == 0:
        # Без интервала
        keyboard.write(text)
    else:
        # с интервалом
        for txt in text:
            keyboard.write(txt)
            time.sleep(interval)


def hotkey(hotkey_key="alt+f4"):
    """Нажимаем горячую клавишу"""
    keyboard.press_and_release(hotkey_key)

